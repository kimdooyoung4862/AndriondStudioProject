package com.bitcamp.app.Activity.Activity1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.bitcamp.app.kakao.R;

public class MemberDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.member_detail);
    }
}
